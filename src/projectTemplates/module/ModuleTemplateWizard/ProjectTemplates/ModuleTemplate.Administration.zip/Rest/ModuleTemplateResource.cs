using Maze.Administration.Library.Clients;

namespace $safeprojectname$.Rest
{
    public class ModuleNamePlaceholderResource : ResourceBase<ModuleNamePlaceholderResource>
    {
        public ModuleNamePlaceholderResource() : base(null)
        {
        }
    }
}