namespace $safeprojectname$.Views
{
    /// <summary>
    ///     Interaction logic for ModuleNamePlaceholderView.xaml
    /// </summary>
    public partial class ModuleNamePlaceholderView
    {
        public ModuleView()
        {
            InitializeComponent();
        }
    }
}